package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}


@RestController
class ServerController{

	@RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException {
    	String data = "Hello Destinee Herrera!";
    	String algorithm = "SHA-256";
    	
    	//intitialize Message Digest 
    	MessageDigest md = MessageDigest.getInstance(algorithm);
  
        
        //Compute the message digest array
        byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));      
     
       
        //Converting the byte array in to HexString format
        StringBuffer hexString = new StringBuffer();
        
        // In this loop: Get every scrambled byte and translate it to a readable Hex number.
        for (int i = 0;i<digest.length;i++) {
           String hex = Integer.toHexString(0xFF & digest[i]);
           if (hex.length() == 1 ) {
        	   hexString.append('0');
        }
           hexString.append(hex);
        }
       String finalCheckSum = hexString.toString();    
     
  
//return to browser
       return "<p>Data: " + data + "</p>" +
       "<p>Algorithm: " + algorithm + "</p>" +
       "<p>Checksum: " + finalCheckSum + "</p>";
    }
}
